#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <unistd.h>

static int mousefd;
int cx,cy;
extern int w,h;
// mouse init 
int init_mouse(void)
{
	int fd;

	fd = open ("/dev/input/mice",O_RDONLY);
	if (fd < 0)
	{
		printf ("Open /dev/input/mice error\n");
		return -1;
	}
	mousefd = fd;
	
	cx = w / 2;
	cy = h / 2;

	return fd;
}

int read_mouse(void)
{
	static unsigned char buf[8];
	static int dx,dy;
	int ret = -1;

	read (mousefd,buf,8);

        dx   = buf[1] - ((buf[0] & 0x10) ? 256 : 0);
        dy   = -buf[2] + ((buf[0] & 0x20) ? 256 : 0);
	
	cx += dx;
	cy += dy;
	
	if (cx < 0)
		cx = 0;
	if (cx > w)
		cx = w;
	
	if (cy < 0)
		cy = 0;
	if (cy > h)
		cy = h;
	
	if ((buf[0]&0x7) == 1)
	{
		return 0;
	}
	return ret;
	
}


