
int led_set_value(int value);
