
int dip_get_value(void);
