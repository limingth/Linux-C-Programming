
int count_add_one();
int count_add( int num );

int count_get_number();
int count_zero();
