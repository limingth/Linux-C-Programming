
#include <stdio.h>

void mac_test( void )
{
	printf( "<mac.c> mac_test running! \n" );
	return;
}
