
#include <stdio.h>
#include <serial.h>

void serial_test( void )
{
	printf( "<serial.c> serial_test running! \n" );
	return;
}
