
#include <stdio.h>
#include "chat.h"

void chat_test( void )
{
	printf( "<chat.c> chat_test running! \n" );
	return;
}
