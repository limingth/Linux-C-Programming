
#include <stdio.h>
#include "chat.h"

int main( void )
{
	printf( "<test_chat.c> main running! \n" );
	
	chat_test();

	return 0;
}
