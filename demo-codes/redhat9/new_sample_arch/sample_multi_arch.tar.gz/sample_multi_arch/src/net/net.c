
#include <stdio.h>

void net_test( void )
{
	printf( "<net.c> net_test running! \n" );
	return;
}
