
#include <stdio.h>
#include "net.h"

int main( void )
{
	printf( "<test_net.c> main running! \n" );
	
	net_test();

	return 0;
}
