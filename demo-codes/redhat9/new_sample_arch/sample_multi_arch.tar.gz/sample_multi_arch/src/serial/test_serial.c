
#include <stdio.h>
#include "serial.h"

int main( void )
{
	printf( "<test_serial.c> main running! \n" );
	
	serial_test();

	return 0;
}
