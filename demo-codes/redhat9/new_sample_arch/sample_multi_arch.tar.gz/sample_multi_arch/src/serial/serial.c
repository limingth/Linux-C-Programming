
#include <stdio.h>

void serial_test( void )
{
	printf( "<serial.c> serial_test running! \n" );
	return;
}
