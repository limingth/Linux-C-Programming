/*
 * Automatically generated C config: don't edit
 */
#define AUTOCONF_INCLUDED

/*
 * Target Platform Selection
 */

/*
 * Choose a Vendor/Product combination.
 */
#define CONFIG_DEFAULTS_INTEL_I386 1
#undef  CONFIG_DEFAULTS_ARM_INTEL_XSCALE
