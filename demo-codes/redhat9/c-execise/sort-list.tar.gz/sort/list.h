
struct lnode_t 
{
	char * pline;  		/* pointer to one line */
	struct lnode_t * next;	/* pointer to next lnode */
};

typedef struct lnode_t lnode;


