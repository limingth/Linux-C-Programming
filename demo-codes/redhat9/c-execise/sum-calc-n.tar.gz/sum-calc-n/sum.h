/*
	calN.c   -- calculate how many N in a number
	author:	li ming
	date:   2006-09-18
	version:   1.0
*/


/* calculate how many 9 in int n, return x is the sum */
int sum_cal_n( int begin, int end, int number);

